						-= SYLVIAN  METTLE =-
						   [By Videogames]

---===[Words]===---

	A little bit of everything! New Infantry, Buildings, Turrets, Landmines, Upgrades, Tanks, Mechs, Ships, 
	Submarines, Fighter Jets, Helicopters, Experimentals, Landships, Artillary, Bunkers, Carriers...


---===[Links]===---

	Steam Page:
	https://steamcommunity.com/sharedfiles/filedetails/?id=1304665634

	New Fangled Discord:
	https://discord.gg/rVnFPMJ

---===[Changelog]===---

	Update: [April-5-2019] to [May-30-2019]
	V1.1.3 Beta:

		Added:
			Heavy Experimental Hangar
			Infantry Engineer
			Vanguard
			Excelsior
			Seadragon
			Bastion
			Marshall
			Samurai
			Raptor
			Nightmare
			Chemical Missile
			Incendiary Missile
			EMP Missile
			Cluster-Mine Missile
			Orbital Transport
			Fortress Ship
			Sea Platform Minigun
			Sea Platform Oil Drill
			Sea Experimental Hangar
			Small Artillary Bunker
			Small Minigun Bunker
			Small Anti-Missile Bunker
			Small Anti-Air Bunker

		Changes:
			Various unit icons added
			All fighters now use the improved dogfighting AI
			Unicorn 'Shield-breaker' firemode
			Dolphin HP increased to 3000
			Velarus now produces 15 income
			Landmines recoded to be more stable
			MCV build lists should no-longer load improperly
			Thunderhead, Landcruiser, and Medium Carrier removed from T-2 factory
			Heavy assault mechs are now built from Experimental Factory
			Velarus & Titan are now built from the Heavy Experimental Hangar
			Restored unused Chimera & Titan team color sprites
			Various custom action icons added
			Tweaked Unicorn Firing Animation
			Tweaked Hermes targeting AI
			A.T.E. now carriable by infantry transports
			Mech jump-jet duration 30% longer
			Nuclear fallout duration increased to 4 minutes
			Starbuck can now build more types of sea platforms
			Sea platform AA-gun replaced with minigun
			Perimiter towers can now be built on cliffs
			Manticore can be equipped with special bomb payload
			Submarines now get substantial nuke damage reduction while underwater
			Small Carrier factory buff increased from 25% to 50%
			Medium Carrier factory buff increased from 50% to 100%
			Mediun Carrier cost increased from 20k to 25k
			Manticore Bomber price increased from 7500 to 10000
			Scorcher HP increased from 750 to 1500
			Removed most T-1 buildings from engineer & experimental
			Improved sea-mine building behavior
			Warden chaingun now has a slight spread
			Infantry HMG has reduced accuracy when mobile
			Updated weapon effects for heavy assault mechs
			Tweaked projectile behavior for Stalker & Egret mechs

	Update: Dec-5-2018
	A Patch For Intelligence

	Update: from [Oct-31] to [Dec-4] 2018
	V1.1.1:
	"Armageddon" Major Update
	
		Added:
			Combat Divers
			Pegasus Infantry
			Infantry Transport
			Manticore Bomber
			Experimental Refinery
			Light Missile Silo
			Strategic Defence Complex
			Launch Center
			
			Sensor Ping
			Landing Pod
			Shield Jammer
			Nano Overcharge
			Dirty Bomb
			M.I.R.V.
			Kinetic Strike
			Nicoll Dyson Beam
	
		Changes:
			The Eris bomber now drops depth charges
			Added light missiles to the Robin & Eagle fighters
			Added jump-jet capability for Lemur and Eris mechs
			Changed the ATR back to 15 rockets & increased firing speed
			Increased the infantry mortar range from 300 to 400
			Aircraft now respect firing angle restrictions
			The Airframe Interceptor now requires ammo
			Both Carriers are now able to transport their respective tags
			Carriers can now actually service aircraft
			Added transport tags to most ships
			Converted Shieldbearer graphics to new API
			Reduced the deploy speed of artillary weapons
			Added particle effects to harvesters & factories
			Added custom muzzle effects to infantry
			Fixed upgrade trees for Anti-Air bunker
			Smoothed Yukana firing animations
			Fixed Refinery sprite alignment when upgraded

	V1.1.1-Beta Branch Only:

		Added:
			Combat Divers
			Pegasus Infantry
			Infantry Transport

		Changes:
			New bad particle effects for the Buzzard, Carrier, Chimera, Condor, Dragonfly, Eagle, Eris, Fairchild, Hermes, Landcrawler, 
			Landship, Orca, RIB, Robin, Selenium, Skycat, Stewart, Tabby, Thunderstorm II, Typhoon, and Warden.
			The Battlewagon can now transport infantry
			The Transport RIB can now transport infantry
			Increased Transport RIB capacity to 4

	Update: 
	V1.1.0-B: Unstable Branch
	
		Changes:
			Removed Stability

	Update: Oct 31 @ 10:48am
	V1.1.0:
	"New Toys" Major Update
	
		Added:
			APWS Artillery Cannon
			Yukana Heavy Battle Tank
			Shieldbearer Laser Defense Truck
			Tabby Advanced Corvette
			Infantry Transport RIB
			Thunderstorm Biplane
			Dolphin Transport Airship
			Brutus Heavy Air-Battleship
			Egret Heavy Infantry Assault Mech
			Theta Medium/Large Seige Mech
			Ravager Laser Assault Mech
			Velarus Mobile Command Center
			Small Repair Turret
			Heavy Rocket Bunker

		Changes:
			Reorganized the sea & air factory build lists... again
			Changed the firing sounds of the Impostor and Chisel to be less annoying
			Changed the hitbox on the Hermes to make sense
			Reduced the Flamingo's price from 4200 to 3500
			Increased the Fairchild's price from 2000 to 2500
			Increased the Starbuck's price from 3000 to 3500
			Sea Mines can now by built by the Starbuck
			Tier-3 Barracks are now 50% faster
			New sprite for the Airship Hangar
			Changed the Unicorn's description
			Added transport description to the Typhoon
			Increased the draw layer of the Titan & Chimera
			Fixed the slow animation speed on the Scarab
			Fixed infantry HMG bullet deflection
			Reduced the Robin's speed to 3.1
			Reduced the Eagle's speed to 3.3
			Reduced the Dragonfly's speed to 2.7
			Reduced the Kestrel's speed to 0.8
			
			Added Yoloskeet to the Ministry of Bad Mod Choices
			
			Removed dawae6464 from Uganda
			Removed phantom_reaper from the Otaku convention
			Removed xX_slayerofheresy_Xx from Fazeclan
			Removed StaRK from The Avengers
			Removed KRAYTEK_999 from international waters

	Update: Oct 19 @ 11:02am
	V1.0.9-2:
	"Its Still Bad" Patch
	
		Added:
			Added Eris Bomber
			Added a Teir-4 upgrade to industrial stores
			Added Dragonfly scout/gunship
			Added Elite Marksman
			Added Arachnid Mech
			Added "Primed Dissapointment"

		Changes:
			Reorganized more boring file-structure crap
			Increased the Impostor's cost to 7000
			ATE's attack range increased to 450
			Increased all factory income slightly
			Reorganized the carrier build list
			Medium Carrier launch speed +50%
			The Pigeon is now called the Robin, get used to it
			The Fighter hitboxes are now the correct size
			Fixed the Robin, Orca, and T-3 Barracks dissapearing from build list in some situations
			Railgunners can now attack aircraft, Yay!
			Strike-Launcher price increased to 2500 & hp increased to 250
			Individual mortar shells have less area-of-effect but spread out more

	Update: Oct 17 @ 3:32am
	v1.0.9:

		Added:
			Thunderhead Artillary Ship
			Starbuck Support Ship
			Medium Carrier
			Heavy Chaingun Turret
			
			(Secret Spookies)

		Changes:
			Buffed the damage of the Heavy Autocannon Turret
			The ATR now fires only 10 rockets but does increased damage
			The ATR now has a deployed state similar to the ATE
			Completely reorganized build list for defences
			Rebalanced the cost of the small and large bunker turrets
			Buffed the damage of the Chimera's autocannons
			Reduced cost of the selenium submarine to 14K
			Small Carrier can now only produce light fighters
			Fighter AI improved slightly
			The Pigeon can use it's cannon to attack ground targets
			The Eagle can now drop light bombs on ground targets
			
			Removed RAMK3 from Area52 Meme-Storage Facility
			Removed V1VA257 from the Society of Witchcraft Apologists
			Removed YoloSkeet from Underwater Leg-Day

	Update: Oct 8 @ 12:33pm
	v1.0.8:
	"I'D SHIP IT! Release"

		Added:
			Sea Mine (Placed by builder ships)
			Dingo Infantry Mech
			Stewart Assault Ship
			Hermes Torpedo Ship
			Fairchild Missile Cruiser
			Selenium Attack Submarine

		Changes:
			Tweaked the AI of the Typhoon to make it more reliable.
			Rebalanced the costs and healths of most of the low-teir mechs.
			(Stalker, Lemur, Flamingo, Scorcher)
			Fixed the particle effects on the Landship and Landcruiser.

	Update: Sep 15 @ 9:19pm
	v1.0.7-2:
	The same - But different update

		Changes:
			Increased cost of the ATR to 7500.
			Increased cost of the Nuke Truck to 17500.
			Increased the cost of the Rocket Silo to 7500.
			Reduced the movement speed of the ATR to 0.8.
			Doubled the reload times of ATR and the Rocket Silo.
			Reduced the fire-rate of the Rocket Silo by 50% (While in ripple mode)

	Update: Sep 13 @ 5:06pm
	v1.0.7:
	Miscellaneous Inconsequential Update

		Added:
			HMG Turret
			GMG Turret
			Mortar Turret
			SAM Turret
			Heavy SAM Turret
			Diamondback Light Tank

		Changes:
			Moderatey reduced the health of T-1 Infantry
			Slighty reduced the health of Scouts and IFVs
			Discuss this update in the discussions section.

	Update: Sep 6 @ 7:22pm
	v1.0.6-2:
	Super Secret Update

		Added:
			(Not implemented yet) Cluster Mine
			(Not implemented yet) Small Missile Silo
			(Not implemented yet) Turret Foundation

		Changes:
			Made a 'third pass' over collisions and origins on structural walls and buildings.
			There should be alot less misclicks and UI bugs when selecting smaller structures and ordering attacks.

			(Reorganized some stuff behind the scenes for future updates and merged some redundant sprite files.)

	Update: Sep 5 @ 10:25pm
	v1.0.6:

		Added:
			'Scarab' AA IFV (Reworked from the original mod!)
			'Hound' IFV (Reworked from the original mod!)
			'Rhino' Tank
			A.T.E. Artillary Gun
			A.T.R. Rocket Truck
			Infantry Grenadier
			Infantry Phantom
			Infantry Scabrewolf
			Infantry Fencer
			Infantry Mine Disposal
			'Stalker' Infantry Mech (Reworked from the original mod!)
			'Lemur' Railgun Mech
			'Parrot' Light Fighter

		Changes:
			All infantry can now climb over cliffs
			Fixed the firing animation of the Lancer tank
			Reduced the reload time of the Lancer tank
			Reorganized the infantry build list
			Reorganized the vehicle build list

	Update: Aug 28 @ 5:54am
	v1.0.5: "Odds and ends"

		Added:
			'Buzzard' Heavy Attack Helicopter
			'Kestrel' Heavy Frigate
			'Flamingo' Transforming VTOL Mech
			Wall Variants; Brick Wall
			Teired Fabricators; Solar Farm, Oil Tanks, Industrial Stores

		Changes:
			Reduced the anti-missile defence on the Eagle Fighter
			Increased the cost of the Skycat to 3500
			Increased the cost of the Warden to 25000
			The Chisel can now transport units, it holds 3 units
			Doubled the fire-rate of the Chimera's cannons but halved damage
			Refactored the construction time on the airships
			Refactored the construction time on the experimentals

	Update: Aug 22 @ 6:08pm
	v1.0.4-2:
	Micro-update

		Added:
			Minelaying Truck
			'Condor' Transport Heli

		Changes:
			The Small Carrier now holds 6 units
			The ground targeting on the Skycat is improved

	Update: Aug 22 @ 3:11pm
	v1.0.4: Fix
		
		Fix to possible steampipe or RW update bug that didn't update the sprite files
		Discuss this update in the discussions section.
	
	Update: Aug 22 @ 5:23am
	v1.0.4:

		Added:
			'Patriot' Scout vehicle
			'Battle Wagon' Transport
			Infantry 'Strike Launcher'
			'Scorcher' Flame Mech
			'Chimea' Experimental Mech
			'Orca' Transport Helicopter
			'Skycat' Attack Helicopter
			Small Aircraft Carrier
			'Chisel' Heavy Airship
			~ Eternety Cannon

		Changes:
			Custom missile sprite for the Landship, Landcruiser, and Warden Mech.
			Added 'splash effect' to airships and fighters.
			Tweaked collision problems on the Landcruiser.
			Reworked AI values for bunkers & tanks/artillary.
			Fixed broken strings on infantry and vehicle descriptions

	Update: Aug 18 @ 2:20am
	v1.0.3:

		Added:
			Eagle jet fighter
			'Landship' & 'Landcruiser'
			Nuclear warhead truck
			Warden heavy assault mech
			Assault infantry T-2
			Mortar infantry T-2
			Railgun infantry T-2
			Anti-air sea-bunker
			Heavy flak cannon bunker
			Airframe interceptor bunker
			"Large bunker" artillary

		Changes:
			Raised the cost of the Unicorn to 9000
			Custom projectile sprites for rocket bunker
			Tweaked the upgrade tree for sea-bunkers
			Tweaked the upgrade tree flak-cannons

	Update: Aug 14 @ 11:11pm
	v1.0.2:

		Added:
			Lancer Light Assault Tank
			Unicorn Experimentlal Propelled Artillary

		Changes:
			Gave the missile bunker two different firing modes.
			Tweaked the descriptions of the various perimiter towers.

	Update: Aug 14 @ 2:59pm
	v1.0.1:

		Added:
			Missile Bunker
			Sea Platform
			Airship Hangar
			Impostor Light Airship
			Viper Scout IFV

		Changes:
			Increased the cost of the combat medic to 500 (same as engineer).
			Reduced the HP of the Machine-gunner to 100 & 250 prone.
			Reduced the HP of the Marksman to only 50 when not prone 
			(To make them more vunerable when moving).
			Gave the Heavy Artillary Bunker super-fancy firing animations.

		Update: Aug 11 @ 3:52am
		INITIAL RELEASE:

		Added:
			Machine-gun Bunker , Artillary Bunker , Heavy Artillary Bunker
			Anti-air Gun Bunker , Flak Cannon Bunker
			Infantry Barracks , Infantry Barracks II , Infantry Barracks III
			Rifle Grunt , Anti Tank Support , Machine-gunner , Marksman , Combat Medic
			Watchtower (with variants) , Concrete Tower (with variants)
			3-Long Barricade , 6-Long Barricade
			Concrete Block (1-Wide) , Tank Trap (2-Wide)
